var config = {
    apiKey: "AIzaSyDQdUQbB4Adhk1SmIG0TFZphVbCaJfwvbU",
    authDomain: "hswblog-f65cf.firebaseapp.com",
    databaseURL: "https://hswblog-f65cf.firebaseio.com",
    projectId: "hswblog-f65cf",
    storageBucket: "hswblog-f65cf.appspot.com",
    messagingSenderId: "130257869903"
};

module.exports = config;