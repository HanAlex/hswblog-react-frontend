 import React, { Component } from 'react';
 
 class MainRoute extends Component {
     render() {
         return (
             <div>
                 메인111111111
             </div>
         );
     }
 }
 
 export default MainRoute;