import React from 'react';

const Profile = () => {
    return (
        <div>
            프로필
        </div>
    );
};

export default Profile;