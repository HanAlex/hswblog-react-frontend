import { combineReducers } from 'redux';
import header from './header';

const base = combineReducers({
    header
});

export default base;